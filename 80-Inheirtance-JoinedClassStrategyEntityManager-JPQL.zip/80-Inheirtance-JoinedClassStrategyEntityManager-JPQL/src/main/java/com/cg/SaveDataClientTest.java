package com.cg;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Scanner;

import com.cg.entity.Employee;
import com.cg.entity.Person;
import com.cg.entity.Student;
import com.cg.util.JPAUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

public class SaveDataClientTest {
	public static void main(String[] args) throws IOException {	
		EntityManager entityManager = JPAUtil.getEntityManagerFactory().createEntityManager();
			
		Person person = new Person();
		person.setName("Gini Martin");
		person.setGender("Female");
	
		Employee employee= new Employee();
		employee.setBonus(new BigDecimal("507.389"));
		employee.setDeptName("IT");
	
		employee.setEmail("gini@gmail.com");
		employee.setName("Ginie");
		employee.setSalary(22000.2872);
		employee.setGender("Female");
		
		Student student = new Student();
		student.setName("Samaya");
		student.setGender("Female");
		student.setFee(20000.00f);
		student.setSchoolName("Cambridge");
		student.setSectionName("XII");
		
		entityManager.getTransaction().begin();
		entityManager.persist(person);
		entityManager.persist(employee);
		entityManager.persist(student);
        entityManager.getTransaction().commit();
        entityManager.close();
        JPAUtil.shutdown();
 
        
/*
		CRUDOperations crudOperations = new CRUDOperations();
		String ans;
		Scanner sc;
		
do {		
	System.out.println(" Enter Choice");
	sc = new Scanner(System.in);
	int ch = sc.nextInt();
		switch (ch)
		{
		case 1:
			{ crudOperations.insertEntity();
	        break;
			}
		case 2:
			{crudOperations.findEntity();
	        break;
			}
		case 3:
			{crudOperations.updateEntity();
	        break;
			}
		case 4:
			{
	        crudOperations.removeEntity();
	        break;
			}
		}
		System.out.println(" Enter Answer(Yes/No ");
		Scanner sc1 = new Scanner(System.in);
		 ans = sc1.nextLine().trim();
} while (!"q".equals(ans));
}*/
	}
}
