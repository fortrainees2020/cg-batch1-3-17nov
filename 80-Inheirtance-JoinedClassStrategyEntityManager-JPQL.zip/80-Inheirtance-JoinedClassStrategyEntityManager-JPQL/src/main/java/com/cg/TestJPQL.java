package com.cg;

import java.util.List;

import com.cg.entity.Employee;
import com.cg.entity.Student;
import com.cg.util.JPAUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class TestJPQL {

	public static void main(String[] args) {
		 EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
            em.getTransaction().begin();
            Query q = em.createQuery("SELECT x FROM Employee x");
            List<Employee> results = (List<Employee>) q.getResultList();
            for(Employee s: results) {
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" );
                    System.out.println("Empl " + s.getId());
                    System.out.println("Empl " + s.getSalary());
                    System.out.println("Empl " + s.getEmail());
                    System.out.println("Empl " + s.getBonus());
                    
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" );
            }
            em.getTransaction().commit();
            
            //--Delete---------------
            /*
             EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentPU");
             EntityManager em = emf.createEntityManager();
             Query q = em.createQuery("DELETE x FROM Employee x WHERE id > 5");
             int deleted = q.executeUpdate();
             */
            
            
            /*---Updating-----
             * 	EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentPU");
				EntityManager em = emf.createEntityManager();
				Query q = em.createQuery("UPDATE Student x SET x.name = 'Srinivas' WHERE sid > 5");
				int deleted = q.executeUpdate();
             * */
            
            
           /*------------Ordering--------
            * select x from Student x order by x.sid asc, x.name desc
            */
             
	}
}
