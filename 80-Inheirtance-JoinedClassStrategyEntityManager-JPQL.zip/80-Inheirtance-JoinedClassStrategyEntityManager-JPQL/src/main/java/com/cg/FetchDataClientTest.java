package com.cg;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Scanner;

import com.cg.entity.Employee;
import com.cg.entity.Person;
import com.cg.entity.Student;

import com.cg.util.JPAUtil;

import jakarta.persistence.EntityManager;

public class FetchDataClientTest {
	public static void main(String[] args) throws IOException {	
		EntityManager entityManager = JPAUtil.getEntityManagerFactory().createEntityManager();
		
		Person person = entityManager.find(Person.class, 3L);
		
		if(person instanceof Person && !(person instanceof Employee) && !(person instanceof Student))
			System.out.println(person);
		
		if(person instanceof Person && (person instanceof Employee))
		{   Employee emp = emp= (Employee)person;
			System.out.println(emp);
		}
		if(person instanceof Person && (person instanceof Student))
		{   Student student = (Student)person;
			System.out.println(student);
		}
		
        entityManager.close();
        
        JPAUtil.shutdown();
	}
}
 
  